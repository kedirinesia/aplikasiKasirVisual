﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir2
{
    public partial class FormKalkulator : Form
    {
        string angkalayar, op;
        double angka=0, angka2=0, hasil=0, hasil1=0;
        private List<string> historyList = new List<string>();

        private void UpdateHistory(string operation)
        {
            historyList.Add(operation);
            UpdateHistoryDisplay();
        }

        private void UpdateHistoryDisplay()
        {
            listBoxHistory.Items.Clear();
            {
                listBoxHistory.Items.Clear();
                listBoxHistory.Items.AddRange(historyList.ToArray());
            }

        }







        private void button1_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "1";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "1";
                textBox1.Text = angkalayar;
            }
        }

       

        private void button4_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "4";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "4";
                textBox1.Text = angkalayar;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "5";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "5";
                textBox1.Text = angkalayar;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "6";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "6";
                textBox1.Text = angkalayar;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "7";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "7";
                textBox1.Text = angkalayar;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "8";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "8";
                textBox1.Text = angkalayar;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "9";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "9";
                textBox1.Text = angkalayar;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "0";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "0";
                textBox1.Text = angkalayar;
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (angka == 0)
            {
                angka = double.Parse(angkalayar);
                angkalayar = null;
                op = "+";
            }
            else
            {
                angka = hasil;
                angkalayar = null;
                op = "+";
            }
            }

        private void button20_Click(object sender, EventArgs e)
        {
            if (angka == 0)
            {
                angka = double.Parse(angkalayar);
                angkalayar = null;
                op = "-";
            }
            else
            {
                angka = hasil;
                angkalayar = null;
                op = "-";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (angka == 0)
            {
                angka = double.Parse(angkalayar);
                angkalayar = null;
                op = "*";
            }
            else
            {
                angka = hasil;
                angkalayar = null;
                op = "*";
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (angka == 0)
            {
                angka = double.Parse(angkalayar);
                angkalayar = null;
                op = "/";
            }
            else
            {
                angka = hasil;
                angkalayar = null;
                op = "/";
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (angka == 0)
            {
                angka = double.Parse(angkalayar);
                hasil = angka * 0.01;
                textBox1.Text = Convert.ToString(hasil);
                op = "p";
            }
            else
            {
                angka2 = double.Parse(angkalayar);
                hasil = angka2 * 0.01;
                textBox1.Text = Convert.ToString(hasil);
                op = "p";
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            angka2 = double.Parse(angkalayar);
            string operation = $"{angka} {op} {angka2} = {hasil}";
            switch (op)
            {
                case "+":
                    hasil = angka + angka2;
                    textBox1.Text = Convert.ToString(hasil);
                    break;
                case "-":
                    hasil = angka - angka2;
                    textBox1.Text = Convert.ToString(hasil);
                    break;
                case "*":
                    hasil = angka * angka2;
                    textBox1.Text = Convert.ToString(hasil);
                    break;
                case "/":
                    hasil = angka / angka2;
                    textBox1.Text = Convert.ToString(hasil);
                    break;
                case "p":
                    hasil = hasil + hasil1;
                    textBox1.Text = Convert.ToString(hasil);
                    break;
                default:
                    break;
            }
            textBox1.Text = Convert.ToString(hasil);
            UpdateHistory(operation);

        }

        private void button12_Click(object sender, EventArgs e)
        {
            angkalayar = "0";
            textBox1.Text = angkalayar;
            angka = 0;
            textBox1.Text = Convert.ToString(angka);
        }

        public FormKalkulator()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "3";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "3";
                textBox1.Text = angkalayar;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (angkalayar == "0")
            {
                angkalayar = "0";
                angkalayar = "2";
                textBox1.Text = angkalayar;
            }
            else
            {
                angkalayar = angkalayar + "2";
                textBox1.Text = angkalayar;
            }
        }

        private void FormKalkulator_Load(object sender, EventArgs e)
        {

        }
    }
}
