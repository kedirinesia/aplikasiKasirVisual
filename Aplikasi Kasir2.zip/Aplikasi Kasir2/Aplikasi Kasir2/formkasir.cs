﻿namespace Aplikasi_Kasir2
{
    internal class formkasir
    {
    }
}