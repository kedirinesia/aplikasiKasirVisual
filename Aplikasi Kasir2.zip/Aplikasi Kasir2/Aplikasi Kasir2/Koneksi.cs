﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace latihan_dbprogramming
{
    class koneksi
    {
        public SqlConnection GetConn()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=PULUNG\\SQLEXPRESS;Initial Catalog=TABLE;Integrated Security=True";
            return conn;
        }
    }
}
