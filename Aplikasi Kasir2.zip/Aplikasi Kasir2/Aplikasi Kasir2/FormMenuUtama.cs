﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir2
{
    public partial class FormMenuUtama : Form
    {

        
        public static FormMenuUtama menu;
        MenuStrip mnstrip;
        private FormLogin frmLogin;
        private FormKalkulator frmkalku;
        private FormRegister frmRegister;
        private FormTransaksiPenjualan frmTransaksiPenjualan;
        private FormChangePassword frmchangepw;

        private void FrmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmLogin = null;
        }
        FormMasterKasir frmkasir;
        private void frmkasir_fromClosed(object sender, FormClosedEventArgs e)
        {
            frmkasir = null;
        }
        FormMasterBarang frmbarang;
        private void frmbarang_fromClosed(object sender, FormClosedEventArgs e)
        {
            frmbarang = null;
        }
        FormKalkulator frmkalkulator;
      

        private void frmkalkulator_fromClosed(object sender, FormClosedEventArgs e)
        {
            frmkalkulator = null;
        }

        private void frmregist_fromClosed(object sender, FormClosedEventArgs e)
        {
            frmRegister = null;
        }

        private void frmTransaksi_fromClosed(object sender, FormClosedEventArgs e)
        {
            frmTransaksiPenjualan = null;
        }

        private void frmchangepw_fromClosed(object sender, FormClosedEventArgs e)
        {
            frmchangepw = null;
        }



        void LockMenu()
        {
            menuLogin.Enabled = true;
            menuTransaksi.Enabled = false;
            menuLogout.Enabled = false;
            menuEdit.Enabled = true;
            menuView.Enabled = true;
            menuexit.Enabled = true;
            menuMaster.Enabled = false;
            menuLaporan.Enabled = false;
            menuUtility.Enabled = false;
            menu = this;
        }
        public FormMenuUtama()
        {
            InitializeComponent();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (frmLogin == null)
            {
                frmLogin = new FormLogin();
                frmLogin.FormClosed += new FormClosedEventHandler(FrmLogin_FormClosed);
                frmLogin.ShowDialog();
            }
            else
            {
                frmLogin.Activate();
                //frmlogin = new  FormLogin();
                //frmlogin.Show();
            }
        }

        private void menuLogout_Click(object sender, EventArgs e)
        {
            LockMenu();
        }

        private void kasirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmkasir == null)
            {
                frmkasir = new FormMasterKasir();
                frmkasir.FormClosed += new FormClosedEventHandler(frmkasir_fromClosed);
                frmkasir.ShowDialog();
            }
            else
            {
            }
        }

        private void barangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmbarang == null)
            {
                frmbarang = new FormMasterBarang();
                frmbarang.FormClosed += new FormClosedEventHandler(FrmLogin_FormClosed);
                frmbarang.ShowDialog();
            }
            else
            {
                frmbarang.ShowDialog();
                //frmlogin = new  FormLogin();
                //frmlogin.Show();
            }
        }

        private void penjualanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmTransaksiPenjualan == null)
            {
                frmTransaksiPenjualan = new FormTransaksiPenjualan();
                frmTransaksiPenjualan.FormClosed += new FormClosedEventHandler(frmkasir_fromClosed);
                frmTransaksiPenjualan.ShowDialog();
            }
        }

        private void kalkulatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmkalkulator == null)
            {
                frmkalkulator = new FormKalkulator();
                frmkalkulator.FormClosed += new FormClosedEventHandler(frmkasir_fromClosed);
                frmkalkulator.ShowDialog();
            }
        }

        private void registerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmRegister == null)
            {
                frmRegister = new FormRegister();
                frmRegister.FormClosed += new FormClosedEventHandler(frmkasir_fromClosed);
                frmRegister.ShowDialog();
            }
        }

        private void gantiPasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmchangepw == null)
            {
                frmchangepw = new FormChangePassword();
                frmchangepw.FormClosed += new FormClosedEventHandler(frmkasir_fromClosed);
                frmchangepw.ShowDialog();
            }
        }

        private void menuView_Click(object sender, EventArgs e)
        {

        }
    }
    }   
