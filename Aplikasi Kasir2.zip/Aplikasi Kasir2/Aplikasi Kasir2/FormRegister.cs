﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using latihan_dbprogramming;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Drawing.Text;

namespace Aplikasi_Kasir2
{
    public partial class FormRegister : Form
    {
        koneksi Konn = new koneksi();
        private SqlCommand cmd;
        private DataSet ds;
        private SqlDataAdapter da;
        private SqlDataReader rd;
        private string correctUsername = "admin";
        private string correctPassword = "strongpassword123";


        void kondisiawal()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        public FormRegister()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
       
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        void MunculDataKasir()
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();
            cmd = new SqlCommand("select * from TBL_KASIR", conn);
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "TBL_KASIR");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "TBL_KASIR";
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.Refresh();


        }

        private void FormRegister_Load(object sender, EventArgs e)
        {
            kondisiawal();
        }

        private bool IsStrongPassword(string password)
        {
            // Syarat-syarat password
            int minLength = 8;
            bool hasUpperCase = false;
            bool hasLowerCase = false;
            bool hasDigit = false;

            // Periksa panjang password
            if (password.Length < minLength)
                return false;

            // Periksa karakter-karakter password
            foreach (char c in password)
            {
                if (char.IsUpper(c))
                    hasUpperCase = true;
                else if (char.IsLower(c))
                    hasLowerCase = true;
                else if (char.IsDigit(c))
                    hasDigit = true;
            }

            // Periksa apakah password memenuhi semua syarat
            return hasUpperCase && hasLowerCase && hasDigit;
        }

        private void btn1_Click(object sender, EventArgs e)
        {

            if (textBox4.Text != "1")
            {
                MessageBox.Show("KODE SALAH");
                return;
            }

            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox4.Text.Trim() == "")
            {
                MessageBox.Show("PASTIKAN SEMUA FORM DIISI");
                return;
            }
              string password = textBox3.Text;

        if (IsStrongPassword(password))
        {
            MessageBox.Show("Password memenuhi syarat keamanan.", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        else
        {
            MessageBox.Show("Password tidak memenuhi syarat keamanan.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                
        }

                try
                {
                    SqlConnection conn = Konn.GetConn();


                    string query = "INSERT INTO TBL_KASIR VALUES ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')";
                    
                    if(conn.State != ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                  
                    SqlCommand cmd = new SqlCommand(query, conn);
                   

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("DATA BERHASIL DIINPUT");
                    kondisiawal();
                    MunculDataKasir();  // Menampilkan data terbaru setelah memasukkan data baru
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }
    }
