﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using latihan_dbprogramming;

namespace Aplikasi_Kasir2
{
    public partial class FormLogin : Form
    {
        private SqlCommand cmd;
        private DataSet ds;
        private readonly SqlDataAdapter da;
        private readonly SqlDataReader rd;

        koneksi Konn = new koneksi();




        public FormLogin()
        {
            InitializeComponent();
            //btnLogin.Enabled = false;
            
            // Menambahkan event handler untuk KeyPress pada txtPassword
            txtPassword.KeyPress += new KeyPressEventHandler(txtPassword_KeyPress);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // ...
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            SqlDataReader reader = null;
            SqlConnection conn = Konn.GetConn();

            {
                conn.Open();
                cmd = new SqlCommand("select * from TBL_KASIR where Namakasir='"+ txtUsername.Text + "' and PasswordKasir= '"+ txtPassword.Text +"'", conn);
                cmd.ExecuteNonQuery();
                reader = cmd.ExecuteReader();
                if (reader.Read())

                {

                  //
                    FormMenuUtama.menu.menuLogin.Enabled = false;
                    FormMenuUtama.menu.menuLogout.Enabled = true;
                    FormMenuUtama.menu.menuMaster.Enabled = true;
                    FormMenuUtama.menu.menuTransaksi.Enabled = true;
                    FormMenuUtama.menu.menuLaporan.Enabled = true;
                    //Form dashboard = new FormMenuUtama();
                    this.Close();
                    //dashboard.Show();


                    //FormMenuUtama.





                }
                else

                {
                    MessageBox.Show("Password atau Username salah");
                }


            }





            //string username = txtUsername.Text;
            //string password = txtPassword.Text;

            //if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            //{
            //    MessageBox.Show("Belum diisi");
            //}
            //else if (username == "pulung" && password == "admin")
            //{
            //    Form dashboard = new FormMenuUtama();
            //    this.Hide();
            //    dashboard.Show();
            //}
            //else
            //{
            //    MessageBox.Show("Password atau Username salah");
            //}
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // ...
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                // Panggil method btnLogin_Click ketika tombol "Enter" ditekan
                btnLogin_Click(sender, e);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            
            btnLogin_Click(sender, e);


        }

        private void FormLogin_Load(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
          
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
