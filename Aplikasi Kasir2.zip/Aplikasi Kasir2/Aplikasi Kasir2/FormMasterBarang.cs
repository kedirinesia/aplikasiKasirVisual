﻿using latihan_dbprogramming;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplikasi_Kasir2
{
    public partial class FormMasterBarang : Form
    {
        koneksi Konn = new koneksi();
        private SqlCommand cmd;
        private DataSet ds;
        private SqlDataAdapter da;
        private SqlDataReader rd;


        void munculsatuan()
        {
            comboBox1.Items.Add("PCS");
            comboBox1.Items.Add("BOX");
            comboBox1.Items.Add("KG");
            comboBox1.Items.Add("KARUNG");
            comboBox1.Items.Add("GR");
        }
        void kondisiawal()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            comboBox1.Text = "";
            munculsatuan();
            MunculDataBarang();
        }
        void MunculDataBarang()
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();
            cmd = new SqlCommand("select * from TBL_BARANG", conn);
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "TBL_BARANG");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "TBL_BARANG";
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.Refresh();
        }
        void CariBarang()
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();
            cmd = new SqlCommand("select * from TBL_BARANG where KodeBarang like '%"+ textBox6.Text +"%'", conn);
            ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds, "TBL_BARANG");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "TBL_BARANG";
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.Refresh();
        }

        public FormMasterBarang()
        {
            InitializeComponent();
        }

        private void FormMasterBarang_Load(object sender, EventArgs e)
        {
            kondisiawal();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox4.Text.Trim() == "" || textBox5.Text.Trim() == "" || comboBox1.Text.Trim() == "")
            {
                MessageBox.Show("PASTIKAN SEMUA FORM DIISI");
            }
            else
            {
                SqlConnection conn = Konn.GetConn();

                SqlCommand cmd = new SqlCommand("INSERT INTO TBL_BARANG VALUES ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + comboBox1.Text + "')", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("DATA BERHASIL DIINPUT");
                kondisiawal();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox4.Text.Trim() == "" || textBox5.Text.Trim() == "" || comboBox1.Text.Trim() == "")
            {
                MessageBox.Show("PASTIKAN SEMUA FORM DIISI");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();

                        string query = "UPDATE TBL_KASIR SET KodeBarang = @KodeBarang, NamaBarang = @NamaBarang, HargaBeli = @HargaBeli, Hargajual = @Hargajual, JumlahBarang = @JumlahBarang WHERE [Satuan Barang] = @SatuanBarang";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@KodeBarang", textBox1.Text);
                            cmd.Parameters.AddWithValue("@NamaBarang", textBox2.Text);
                            cmd.Parameters.AddWithValue("@HargaBeli", textBox3.Text);
                            cmd.Parameters.AddWithValue("@Hargajual", textBox4.Text);
                            cmd.Parameters.AddWithValue("@JumlahBarang", textBox5.Text);
                          cmd.Parameters.AddWithValue("@SatuanBarang", comboBox1.Text);  

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("DATA BERHASIL DI Edit");
                                kondisiawal();
                            }
                            else
                            {
                                MessageBox.Show("Tidak ada data yang diubah.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            CariBarang();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            textBox1.Text = row.Cells["KodeBarang"].Value.ToString();
            textBox2.Text = row.Cells["NamaBarang"].Value.ToString();
            textBox3.Text = row.Cells["HargaBeli"].Value.ToString();
            textBox4.Text = row.Cells["HargaJual"].Value.ToString();
            textBox5.Text = row.Cells["JumlahBarang"].Value.ToString();
            comboBox1.Text = row.Cells["SatuanBarang"].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "" || textBox2.Text.Trim() == "" || textBox3.Text.Trim() == "" || textBox4.Text.Trim() == "" || textBox5.Text.Trim() == "" || comboBox1.Text.Trim() == "")
            {
                MessageBox.Show("PASTIKAN SEMUA FORM DIISI");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();

                        string query = "DELETE FROM TBL_BARANG WHERE KodeBarang = @KodeBarang";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@KodeBarang", textBox1.Text);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("DATA BERHASIL DIHAPUS");
                                kondisiawal();
                            }
                            else
                            {
                                MessageBox.Show("Tidak ada data yang dihapus.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
